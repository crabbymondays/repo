import os
import json
import random
import sys
import time
from urllib.parse import parse_qs, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from lib.art_cache import ArtworkCache
from lib.catalogue_clients import CatalogueError
from lib.core import Curator
from lib.list_art import resolved_sources as resolved_list_art
from lib.metadata_cache import MetadataCache
from lib.menu_art import menu_source
from lib.player_registry import PlayerRegistry
from lib.trakt import TraktError
from lib.view_refresh import list_signature, refresh_if_changed


ADDON = xbmcaddon.Addon()
NAME = ADDON.getAddonInfo("name") or "curatr"
BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
MEDIA_PATH = os.path.join(ADDON_PATH, "resources", "media")
MENU_BACKGROUND_STYLE = "0"
PLAYERS = PlayerRegistry(ADDON)
METADATA = MetadataCache(ADDON)
_LIBRARY_CACHE = {}


def _loc(string_id, fallback):
    try:
        value = str(ADDON.getLocalizedString(int(string_id)) or "").strip()
        if value:
            return value
    except Exception:
        pass
    return str(fallback)


def _params():
    query = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
    parsed = parse_qs(query, keep_blank_values=True)
    return {key: values[-1] if values else "" for key, values in parsed.items()}


def _url(**params):
    return BASE_URL + ("?" + urlencode(params) if params else "")


def _plugin_command(action, **params):
    """Return a context-menu command that works for a Video-only add-on."""
    return "RunPlugin(%s)" % _url(action=action, **params)


def _safe_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _setting_enabled(setting_id, default=True):
    try:
        value = str(ADDON.getSetting(setting_id) or "").strip().lower()
    except Exception:
        value = ""
    if not value:
        return bool(default)
    return value in ("true", "1", "yes", "on")


def _mark_curatr_item(item):
    try:
        item.setProperty("CuratrItem", "true")
    except Exception:
        pass


def _in_video_navigation():
    """Dialog shortcuts in home widgets must not execute during widget probing."""
    try:
        if xbmcgui.getCurrentWindowId() == 10025:
            return True
    except Exception:
        pass
    try:
        return bool(xbmc.getCondVisibility("Window.IsActive(videos)"))
    except Exception:
        return False


def _relative_time(timestamp, verb="Refreshed"):
    value = _safe_int(timestamp, 0)
    if not value:
        return "Not refreshed yet" if verb == "Refreshed" else "Not updated yet"
    seconds = max(0, int(time.time()) - value)
    if seconds < 90:
        return "%s just now" % verb
    minutes = seconds // 60
    if minutes < 60:
        return "%s %d minute%s ago" % (verb, minutes, "" if minutes == 1 else "s")
    hours = seconds // 3600
    if hours < 24:
        return "%s %d hour%s ago" % (verb, hours, "" if hours == 1 else "s")
    days = seconds // 86400
    if days == 1:
        return "%s yesterday" % verb
    if days < 14:
        return "%s %d days ago" % (verb, days)
    weeks = max(2, days // 7)
    if weeks < 9:
        return "%s %d weeks ago" % (verb, weeks)
    months = max(2, days // 30)
    return "%s %d months ago" % (verb, months)


def _summary_plot(summary, description=""):
    summary = str(summary or "").strip()
    description = str(description or "").strip()
    return "%s\n\n%s" % (summary, description) if description else summary


def _list_metadata(record):
    movies = [row for row in record.get("movies", []) if isinstance(row, dict)]
    count = len(movies) or _safe_int(record.get("last_result_count"), 0)
    method = "Keyword Matching" if str(record.get("generation_method") or "ai").lower() == "keyword" else "Personalised"
    content = {"shows": "TV Shows", "both": "Movies & TV Shows"}.get(str(record.get("content_type") or "movies"), "Movies")
    summary = "%d item%s • %s • %s • %s" % (
        count, "" if count == 1 else "s", content, method,
        _relative_time(record.get("updated_at"), "Refreshed"),
    )
    description = str(record.get("description") or "").strip()
    return summary, _summary_plot(summary, description)


def _folder_metadata(folder):
    count = len([row for row in folder.get("entries", []) if isinstance(row, dict)])
    summary = "%d item%s • %s" % (
        count, "" if count == 1 else "s", _relative_time(folder.get("updated_at"), "Updated"),
    )
    return summary, _summary_plot(summary, folder.get("description"))


def _existing_art(filename):
    if not filename:
        return ""
    # Menu glyphs live in a versioned directory so Kodi/Xbox cannot reuse a
    # stale texture merely because a published filename stayed the same.
    path = (menu_source(ADDON_PATH, filename) if str(filename).startswith("menu_")
            else os.path.join(MEDIA_PATH, filename))
    return path if xbmcvfs.exists(path) else ""


def _apply_menu_art(item, icon_name="", custom_art=None):
    # Keep navigation glyphs as item icons while every menu entry uses the
    # same restrained global background. Never promote an icon or per-menu
    # image to fanart: many TV skins display that artwork full-screen.
    background_style = str(MENU_BACKGROUND_STYLE or "0")
    icon = _existing_art(icon_name)

    background_names = {
        "0": "fanart_menu_clean_v4.jpg",
        "1": "background_1_v4.jpg",
        "2": "background_2_v4.jpg",
        "3": "background_3_v4.jpg",
    }
    fanart = _existing_art(background_names.get(background_style, background_names["0"]))
    landscape = ""
    if icon_name:
        landscape_path = menu_source(ADDON_PATH, icon_name, landscape=True)
        if xbmcvfs.exists(landscape_path):
            landscape = landscape_path

    if not icon:
        root_icon = os.path.join(ADDON_PATH, "icon.png")
        if xbmcvfs.exists(root_icon):
            icon = root_icon

    art = dict(custom_art or {})
    if icon:
        art.setdefault("icon", icon)
        art.setdefault("thumb", icon)
    if fanart:
        art.setdefault("fanart", fanart)
        art.setdefault("landscape", landscape or fanart)
    if art:
        try:
            item.setArt(art)
        except Exception:
            pass


def _add_folder(label, action, plot="", context_items=None, icon_name="", art=None, tagline="", **params):
    item = xbmcgui.ListItem(label=label, offscreen=True)
    _mark_curatr_item(item)
    try:
        info = {"title": label, "plot": plot or ""}
        if tagline:
            info["tagline"] = tagline
        item.setInfo("video", info)
    except Exception:
        pass
    try:
        tag = item.getVideoInfoTag()
        tag.setTitle(label)
        if plot:
            tag.setPlot(plot)
        if tagline:
            tag.setTagLine(tagline)
            item.setProperty("tagline", tagline)
    except Exception:
        pass
    _apply_menu_art(item, icon_name, custom_art=art)
    if context_items:
        try:
            item.addContextMenuItems(context_items)
        except Exception as exc:
            xbmc.log("curatr folder context menu skipped: %s" % exc, xbmc.LOGDEBUG)
    xbmcplugin.addDirectoryItem(HANDLE, _url(action=action, **params), item, isFolder=True)


def _add_action(label, command, plot="", icon_name="", widget_fallback=""):
    item = xbmcgui.ListItem(label=label, offscreen=True)
    _mark_curatr_item(item)
    try:
        item.setInfo("video", {"title": label, "plot": plot or ""})
    except Exception:
        pass
    try:
        tag = item.getVideoInfoTag()
        tag.setTitle(label)
        if plot:
            tag.setPlot(plot)
    except Exception:
        pass
    _apply_menu_art(item, icon_name)
    item.setProperty("IsPlayable", "false")
    widget_safe = bool(widget_fallback and not _in_video_navigation())
    target = _url(action=widget_fallback) if widget_safe else _url(action="run", command=command)
    xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=widget_safe)


def _add_route_action(label, action, plot="", art=None, icon_name="", **params):
    """Run a dialog-style route without making Kodi enter another folder."""
    item = xbmcgui.ListItem(label=label, offscreen=True)
    _mark_curatr_item(item)
    try:
        item.setInfo("video", {"title": label, "plot": plot or ""})
        item.setProperty("IsPlayable", "false")
    except Exception:
        pass
    _apply_menu_art(item, icon_name, custom_art=art)
    xbmcplugin.addDirectoryItem(HANDLE, _url(action=action, **params), item, isFolder=False)


def _managed_records(curator):
    records = [row for row in curator.state.get("ai_lists", []) if isinstance(row, dict)]
    records.sort(key=lambda row: _safe_int(row.get("updated_at"), 0), reverse=True)
    return records


def _record_art(curator, record):
    """Resolve both square and landscape list art without making widgets fragile."""
    try:
        art = resolved_list_art(ADDON, record)
        cache = ArtworkCache(ADDON, workers=2)
        resolved = {}
        for key, source in art.items():
            source = str(source or "").strip()
            if not source:
                continue
            if source.startswith("https://") or source.startswith("http://"):
                source = cache._download(source)
            if source and (source.startswith(("special://", "image://")) or xbmcvfs.exists(source)):
                resolved[key] = source
        return resolved
    except Exception as exc:
        xbmc.log("curatr list artwork skipped: %s" % exc, xbmc.LOGWARNING)
        return {}


def _root(curator):
    xbmcplugin.setPluginCategory(HANDLE, NAME)
    _add_folder(
        _loc(32410, "My Lists"), "my",
        _loc(32414, "Create, browse and manage your personalised movie and TV lists."),
        icon_name="menu_my_lists.png",
    )
    _add_folder(
        _loc(32411, "Explore"), "explore",
        _loc(32415, "Quick picks, saved prompts and more ways to browse recommendations."),
        icon_name="menu_explore.png",
    )
    _add_folder(
        _loc(32412, "Preferences & Activity"), "taste_activity",
        _loc(32416, "View your preferences, connections, usage and recent activity."),
        icon_name="menu_taste_v3.png",
    )
    _add_action(
        _loc(32413, "Settings"), "settings",
        _loc(32417, "Set up services, defaults, appearance and notifications."),
        icon_name="menu_settings.png",
    )
    _add_action(
        _loc(32640, "Privacy & Data"), "privacy",
        _loc(32641, "See what curatr stores locally and what optional services receive."),
        icon_name="menu_privacy.png",
    )
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _my(curator):
    xbmcplugin.setPluginCategory(HANDLE, _loc(32410, "My Lists"))
    _add_folder(_loc(32418, "Browse My Lists"), "lists", _loc(32419, "Open and browse your saved lists."), icon_name="menu_list.png")
    _add_action(_loc(32420, "Create a New List"), "create", _loc(32424, "Describe what you want to watch and create a personalised list."), icon_name="menu_create_v2.png")
    _add_action(_loc(32421, "Manage My Lists"), "manage", _loc(32425, "Change list names, prompts, artwork and refresh settings."), icon_name="menu_manage.png")
    _add_folder("Folders", "folders", "Organise lists and shortcuts into custom folders for browsing or widgets.", icon_name="menu_widget_folders.png")
    _add_action(_loc(32422, "Refresh All Lists"), "update", _loc(32426, "Refresh every saved list using its chosen creation method."), icon_name="menu_refresh.png")
    _add_action(_loc(32423, "Backup & Restore"), "backup", _loc(32427, "Save or restore a backup of your lists, prompts, hidden items and folders."), icon_name="menu_backup.png")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _explore(curator):
    xbmcplugin.setPluginCategory(HANDLE, _loc(32411, "Explore"))
    _add_action(
        _loc(32430, "Quick Pick"), "quick",
        _loc(32433, "Choose a mood and quickly create a personalised list with AI."),
        icon_name="menu_quick.png", widget_fallback="explore",
    )
    _add_action(_loc(32431, "Saved Prompts"), "templates", _loc(32434, "Reuse and manage prompts you have saved for later."), icon_name="menu_templates.png")
    _add_folder("All Picks", "all", "Browse recommendations from all your current lists.", icon_name="menu_all.png")
    _add_folder("Latest Picks", "fresh", "See recommendations from the list refreshed most recently.", icon_name="menu_fresh.png")
    _add_folder("Surprise Me", "random", "Browse a random selection from your lists.", icon_name="menu_random.png", limit="10")
    _add_action(_loc(32432, "Hidden"), "hidden", _loc(32435, "Review movies and TV shows you have asked curatr not to recommend."), icon_name="menu_hidden.png")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _taste_activity(curator):
    xbmcplugin.setPluginCategory(HANDLE, _loc(32412, "Preferences & Activity"))
    _add_action(_loc(32440, "Refresh Preferences"), "sync", _loc(32446, "Update the ratings and watch history curatr uses."), icon_name="menu_refresh.png")
    _add_action(_loc(32441, "View My Preferences"), "taste", _loc(32447, "See the information curatr uses when choosing recommendations."), icon_name="menu_taste_v3.png")
    _add_action(_loc(32442, "AI Usage"), "usage", _loc(32448, "See usage statistics reported by your AI provider."), icon_name="menu_usage.png")
    _add_action(_loc(32443, "Recent Activity"), "activity", _loc(32449, "See recent actions, updates and errors."), icon_name="menu_activity.png")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _lists(curator):
    xbmcplugin.setPluginCategory(HANDLE, _loc(32410, "My Lists"))
    records = _managed_records(curator)
    if not records:
        _add_action("Create your first list", "create", "You do not have any saved lists yet.")
    else:
        for record in records:
            local_id = curator._record_key(record)
            if not local_id:
                continue
            name = str(record.get("name") or "curatr list")
            tagline, plot = _list_metadata(record)
            context = [
                ("Refresh this list", _plugin_command("refresh_list", list_id=local_id)),
                ("Sync to Trakt", _plugin_command("sync_list", list_id=local_id)),
                ("Create Similar List", _plugin_command("create_related_local", list_id=local_id)),
                ("Add to Folder", _plugin_command("folder_add_list", list_id=local_id)),
                ("Artwork", _plugin_command("artwork_list", list_id=local_id)),
                ("List settings", _plugin_command("edit_list", list_id=local_id)),
                ("Delete this list", _plugin_command("delete_list", list_id=local_id)),
            ]
            _add_folder(
                name, "list", plot=plot, context_items=context,
                icon_name="menu_list.png",
                art=_record_art(curator, record), tagline=tagline,
                list_id=local_id, name=name
            )
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _folders(curator):
    xbmcplugin.setPluginCategory(HANDLE, "Folders")
    folders = curator.widget_folders()
    _add_action("Create a Folder", "folder_create", "Create a fully customisable folder for your lists. Supported sources include curatr, Kodi Library, Trakt, MDBList and add-on paths.", icon_name="menu_add_folder.png")
    if folders:
        for folder in folders:
            folder_id = str(folder.get("id") or "")
            if not folder_id:
                continue
            name = str(folder.get("name") or "Folder")
            tagline, plot = _folder_metadata(folder)
            context = [
                ("Artwork", _plugin_command("folder_artwork", folder_id=folder_id)),
                ("Folder settings", _plugin_command("folder_manage", folder_id=folder_id)),
                ("Delete folder", _plugin_command("folder_delete", folder_id=folder_id)),
            ]
            _add_folder(
                name, "folder", plot=plot, context_items=context,
                art=_record_art(curator, folder), tagline=tagline, folder_id=folder_id,
            )
        _add_action("Manage Folders", "folders_manage", "Create, edit, reorder or delete folders.", icon_name="menu_manage_folders.png")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _add_external_shortcut(curator, folder, entry):
    path = curator._valid_external_plugin_path(entry.get("path"))
    if not path:
        return False
    name = str(entry.get("name") or "External Shortcut")
    plot = str(entry.get("description") or "").strip() or "Opens the specified path directly."
    item = xbmcgui.ListItem(label=name, offscreen=True)
    try:
        item.setInfo("video", {"title": name, "plot": plot})
    except Exception:
        pass
    try:
        item.setArt(_record_art(curator, entry))
    except Exception:
        pass
    folder_id = str(folder.get("id") or "")
    entry_id = str(entry.get("id") or "")
    external_addon_id = path[len("plugin://"):].split("/", 1)[0].split("?", 1)[0]
    try:
        available = bool(external_addon_id and xbmc.getCondVisibility("System.HasAddon(%s)" % external_addon_id))
    except Exception:
        available = True
    try:
        item.addContextMenuItems([
            ("Artwork", _plugin_command("folder_entry_artwork", folder_id=folder_id, entry_id=entry_id)),
            ("Shortcut settings", _plugin_command("folder_edit_entry", folder_id=folder_id, entry_id=entry_id)),
            ("Remove from folder", _plugin_command("folder_remove_entry", folder_id=folder_id, entry_id=entry_id)),
        ])
    except Exception:
        pass
    target = path if available else _url(action="external_missing", addon_id=external_addon_id, name=name)
    return bool(xbmcplugin.addDirectoryItem(HANDLE, target, item, isFolder=True))


def _add_provider_list_folder(curator, folder, entry):
    provider = str(entry.get("provider") or "").strip().lower()
    if provider not in ("trakt", "mdblist") or not entry.get("provider_list_id"):
        return False
    name = str(entry.get("name") or ("Trakt list" if provider == "trakt" else "MDBList list"))
    service = "Trakt" if provider == "trakt" else "MDBList"
    cache_key = curator._provider_cache_key(provider, entry.get("provider_list_id"))
    cached = (curator.state.get("linked_list_cache") or {}).get(cache_key) or {}
    cached_movies = cached.get("movies") if isinstance(cached, dict) else None
    if isinstance(cached_movies, list) and _safe_int(cached.get("cached_at"), 0):
        count = len(cached_movies)
        tagline = "%d item%s • %s • %s" % (
            count, "" if count == 1 else "s", service,
            _relative_time(cached.get("cached_at"), "Refreshed"),
        )
    else:
        count = _safe_int(entry.get("item_count"), 0)
        count_text = "%d item%s • " % (count, "" if count == 1 else "s") if count else ""
        tagline = "%s%s • Not loaded yet" % (count_text, service)
    description = str(entry.get("description") or "").strip() or "Linked directly to your %s account." % service
    plot = _summary_plot(tagline, description)
    folder_id = str(folder.get("id") or "")
    entry_id = str(entry.get("id") or "")
    context = [
        ("Refresh linked list", "RunPlugin(%s)" % _url(
            action="linked_list", folder_id=folder_id, entry_id=entry_id, force="1",
        )),
        ("Create Similar List", _plugin_command("create_related_provider", folder_id=folder_id, entry_id=entry_id)),
        ("Artwork", _plugin_command("folder_entry_artwork", folder_id=folder_id, entry_id=entry_id)),
        ("Item settings", _plugin_command("folder_edit_entry", folder_id=folder_id, entry_id=entry_id)),
        ("Remove from folder", _plugin_command("folder_remove_entry", folder_id=folder_id, entry_id=entry_id)),
    ]
    _add_folder(
        name, "linked_list", plot=plot, context_items=context,
        art=_record_art(curator, entry), tagline=tagline, folder_id=folder_id, entry_id=entry_id,
    )
    return True


def _folder(curator, params):
    folder_id = params.get("folder_id")
    folder = curator.widget_folder_by_id(folder_id) or curator.recover_widget_folder(folder_id)
    if not folder:
        xbmc.log("curatr widget requested a folder that is no longer available", xbmc.LOGWARNING)
        xbmcplugin.setPluginCategory(HANDLE, "curatr Folder")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        return
    xbmcplugin.setPluginCategory(HANDLE, str(folder.get("name") or "Folder"))
    added = 0
    for entry in folder.get("entries", []):
        if not isinstance(entry, dict):
            continue
        if entry.get("type") == "curatr_list":
            record = curator._managed_record_by_id(entry.get("list_id"))
            if not record:
                continue
            local_id = curator._record_key(record)
            name = str(record.get("name") or "curatr list")
            tagline, plot = _list_metadata(record)
            context = [
                ("Refresh this list", _plugin_command("refresh_list", list_id=local_id)),
                ("List settings", _plugin_command("edit_list", list_id=local_id)),
                ("Create Similar List", _plugin_command("create_related_local", list_id=local_id)),
                ("Artwork", _plugin_command("artwork_list", list_id=local_id)),
                ("Remove from folder", _plugin_command("folder_remove_entry", folder_id=str(folder.get("id") or ""), entry_id=str(entry.get("id") or ""))),
            ]
            _add_folder(name, "list", plot=plot, context_items=context, art=_record_art(curator, record), tagline=tagline, list_id=local_id, name=name)
            added += 1
        elif entry.get("type") == "external_path" and _add_external_shortcut(curator, folder, entry):
            added += 1
        elif entry.get("type") == "provider_list" and _add_provider_list_folder(curator, folder, entry):
            added += 1
    if not added:
        _add_folder("Manage this folder", "folder_manage", "Add items to this folder.", icon_name="menu_manage_folders.png", folder_id=str(folder.get("id") or ""))
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _movie_rows_for_list(curator, list_id):
    record = curator._managed_record_by_id(list_id)
    if not record:
        return []
    movies = [m for m in (record.get("movies") or []) if isinstance(m, dict)]
    if movies:
        return [({}, movie) for movie in movies]

    # Migration fallback for a record that has never been refreshed
    # under local-first mode. If OAuth still works, import its current contents
    # once; otherwise the user can simply refresh the list to build it locally.
    remote_id = record.get("trakt_id")
    if remote_id and curator._has_oauth():
        try:
            rows = curator.trakt.list_items(remote_id, limit=100, extended=True)
            result = []
            local_movies = []
            for row in rows if isinstance(rows, list) else []:
                if not isinstance(row, dict):
                    continue
                media_type = "show" if isinstance(row.get("show"), dict) else "movie"
                movie = row.get(media_type, {})
                if isinstance(movie, dict):
                    movie = dict(movie)
                    movie["media_type"] = media_type
                ids = movie.get("ids") or {} if isinstance(movie, dict) else {}
                if isinstance(movie, dict) and isinstance(ids, dict) and ids.get("trakt"):
                    result.append((row, movie))
                    local_movies.append(movie)
            if local_movies:
                updated = dict(record)
                updated["movies"] = local_movies
                updated["last_result_count"] = len(local_movies)
                curator._store_managed_record(updated, record)
                curator._save_state()
            return result
        except Exception as exc:
            xbmc.log("curatr legacy remote-list import skipped: %s" % exc, xbmc.LOGWARNING)
    return []


def _movie_rows_all(curator):
    seen = set()
    combined = []
    for record in _managed_records(curator):
        list_name = str(record.get("name") or "curatr list")
        list_id = curator._record_key(record)
        try:
            rows = _movie_rows_for_list(curator, list_id)
        except Exception as exc:
            xbmc.log("curatr widget skipped list %s: %s" % (list_name, exc), xbmc.LOGWARNING)
            continue
        for row, movie in rows:
            if curator.is_movie_hidden(movie):
                continue
            trakt_id = _safe_int((movie.get("ids") or {}).get("trakt"), 0)
            marker = (
                str(movie.get("media_type") or "movie"),
                trakt_id or (str(movie.get("title") or "").casefold(), _safe_int(movie.get("year"), 0)),
            )
            if not marker or marker in seen:
                continue
            seen.add(marker)
            combined.append((row, movie, list_name, list_id))
    return combined


def _movie_rows_fresh(curator):
    records = _managed_records(curator)
    if not records:
        return []
    record = records[0]
    list_id = curator._record_key(record)
    name = str(record.get("name") or "Latest List")
    return [(row, movie, name, list_id) for row, movie in _movie_rows_for_list(curator, list_id) if not curator.is_movie_hidden(movie)]


def _movie_rows_random(curator, limit=10):
    rows = list(_movie_rows_all(curator))
    if not rows:
        return []
    # Daily seed avoids widgets jumping around on every Kodi container refresh.
    seed = "%s:%s" % (time.strftime("%Y-%m-%d", time.localtime()), ADDON.getAddonInfo("id"))
    rng = random.Random(seed)
    rng.shuffle(rows)
    return rows[:max(1, min(50, _safe_int(limit, 10)))]


def _safe_tag_call(tag, method, *args):
    try:
        function = getattr(tag, method, None)
        if function:
            function(*args)
            return True
    except Exception as exc:
        xbmc.log("curatr metadata %s skipped: %s" % (method, exc), xbmc.LOGDEBUG)
    return False


def _set_movie_info(item, movie):
    """Populate a movie ListItem without letting one metadata field break a widget.

    Kodi 21 supports InfoTagVideo, but this deliberately uses best-effort setters
    and a legacy setInfo fallback so unusual platform/skin builds still render.
    """
    if not isinstance(movie, dict):
        movie = {}
    media_type = "tvshow" if str(movie.get("media_type") or "movie") == "show" else "movie"
    title = str(movie.get("title") or ("Unknown show" if media_type == "tvshow" else "Unknown movie"))
    year = _safe_int(movie.get("year"), 0)
    overview = str(movie.get("overview") or movie.get("ai_reason") or "")
    tagline = str(movie.get("tagline") or "")
    genres = movie.get("genres") or []
    if not isinstance(genres, list):
        genres = [genres] if genres else []
    runtime = _safe_int(movie.get("runtime"), 0)
    released = str(movie.get("released") or "")
    certification = str(movie.get("certification") or "")
    cast = movie.get("cast") or []
    directors = movie.get("directors") or []
    writers = movie.get("writers") or []
    studios = movie.get("studios") or []
    countries = movie.get("countries") or []
    trailer = str(movie.get("trailer") or "")
    status = str(movie.get("status") or "")
    original_title = str(movie.get("original_title") or "")
    rating = movie.get("rating")
    try:
        rating = float(rating)
    except (TypeError, ValueError):
        rating = 0.0
    votes = _safe_int(movie.get("votes"), 0)
    ids = movie.get("ids") or {}
    if not isinstance(ids, dict):
        ids = {}
    source_ratings = {}
    movie_ratings = movie.get("ratings")
    if not isinstance(movie_ratings, dict):
        movie_ratings = {}
    aliases = {
        "themoviedb": "tmdb",
        "tomatoes": "tomatometerallcritics",
        "audience": "tomatometerallaudience",
    }
    for source, data in movie_ratings.items():
        source = aliases.get(str(source).lower(), str(source).lower())
        if isinstance(data, dict):
            value = data.get("rating")
            source_votes = _safe_int(data.get("votes"), 0)
            percentage = _safe_int(data.get("percent"), 0)
        else:
            value, source_votes, percentage = data, 0, 0
        try:
            value = float(value)
        except (TypeError, ValueError):
            continue
        if value <= 0:
            continue
        if value > 10:
            percentage = percentage or int(round(value))
            value /= 10.0
        percentage = percentage or int(round(value * 10))
        source_ratings[source] = {
            "rating": round(value, 2), "votes": max(0, source_votes),
            "percent": max(0, min(100, percentage)),
        }

    if rating:
        if rating > 10:
            rating /= 10.0
        source = "trakt" if ids.get("trakt") else "tmdb"
        source_ratings.setdefault(source, {
            "rating": round(rating, 2), "votes": max(0, votes),
            "percent": max(0, min(100, int(round(rating * 10)))),
        })
    default_rating = next(
        (source for source in ("trakt", "tmdb", "imdb") if source in source_ratings),
        next(iter(source_ratings), ""),
    )
    if default_rating:
        rating = source_ratings[default_rating]["rating"]
        votes = source_ratings[default_rating]["votes"]

    for source in ("trakt", "tmdb", "imdb", "metacritic"):
        data = source_ratings.get(source)
        if not data:
            continue
        try:
            item.setProperty("Rating.%s" % source, str(data["rating"]))
            item.setProperty("Rating.%s.Votes" % source, str(data["votes"]))
            item.setProperty("Rating.%s.Percent" % source, str(data["percent"]))
        except Exception:
            pass
    tomatoes = source_ratings.get("tomatometerallcritics")
    if tomatoes:
        try:
            item.setProperty("Rating.Tomatoes.Percent", str(tomatoes["percent"]))
            item.setProperty("Tomatometer", "Fresh" if tomatoes["percent"] >= 60 else "Rotten")
        except Exception:
            pass
    audience = source_ratings.get("tomatometerallaudience")
    if audience:
        try:
            item.setProperty("Rating.Popcorn.Percent", str(audience["percent"]))
            item.setProperty("Popcornmeter", "Fresh" if audience["percent"] >= 60 else "Spilled")
        except Exception:
            pass

    # Kodi still supports setInfo in 21.x. Use it as a compatibility baseline,
    # then enrich with the modern InfoTagVideo API where available.
    try:
        legacy = {"title": title, "mediatype": media_type}
        if year:
            legacy["year"] = year
        if overview:
            legacy["plot"] = overview
        if tagline:
            legacy["tagline"] = tagline
        if genres:
            legacy["genre"] = [str(value) for value in genres if value]
        if runtime:
            legacy["duration"] = runtime * 60
        if released:
            legacy["premiered"] = released
        if certification:
            legacy["mpaa"] = certification
        if cast:
            legacy["cast"] = [str(row.get("name") or "") for row in cast if isinstance(row, dict) and row.get("name")]
            legacy["castandrole"] = [
                (str(row.get("name") or ""), str(row.get("role") or ""))
                for row in cast if isinstance(row, dict) and row.get("name")
            ]
        if directors:
            legacy["director"] = directors
        if writers:
            legacy["writer"] = writers
        if studios:
            legacy["studio"] = studios
        if countries:
            legacy["country"] = countries
        if trailer:
            legacy["trailer"] = trailer
        if status:
            legacy["status"] = status
        if original_title:
            legacy["originaltitle"] = original_title
        if rating:
            legacy["rating"] = rating
        if votes:
            legacy["votes"] = votes
        item.setInfo("video", legacy)
    except Exception as exc:
        xbmc.log("curatr legacy metadata fallback skipped: %s" % exc, xbmc.LOGDEBUG)

    try:
        tag = item.getVideoInfoTag()
    except Exception as exc:
        xbmc.log("curatr InfoTagVideo unavailable: %s" % exc, xbmc.LOGDEBUG)
        return

    _safe_tag_call(tag, "setTitle", title)
    if year:
        _safe_tag_call(tag, "setYear", year)
    if overview:
        _safe_tag_call(tag, "setPlot", overview)
    if tagline:
        _safe_tag_call(tag, "setTagLine", tagline)
    if genres:
        _safe_tag_call(tag, "setGenres", [str(value) for value in genres if value])
    if runtime:
        _safe_tag_call(tag, "setDuration", runtime * 60)
    if released:
        _safe_tag_call(tag, "setPremiered", released)
    if certification:
        _safe_tag_call(tag, "setMpaa", certification)
    if cast:
        actor_class = getattr(xbmc, "Actor", None)
        actors = []
        if actor_class:
            for row in cast:
                if not isinstance(row, dict) or not row.get("name"):
                    continue
                try:
                    actors.append(actor_class(
                        str(row.get("name") or ""), str(row.get("role") or ""),
                        _safe_int(row.get("order"), 0), str(row.get("thumbnail") or ""),
                    ))
                except Exception:
                    continue
        if actors:
            _safe_tag_call(tag, "setCast", actors)
    if directors:
        _safe_tag_call(tag, "setDirectors", [str(value) for value in directors if value])
    if writers:
        _safe_tag_call(tag, "setWriters", [str(value) for value in writers if value])
    if studios:
        _safe_tag_call(tag, "setStudios", [str(value) for value in studios if value])
    if countries:
        _safe_tag_call(tag, "setCountries", [str(value) for value in countries if value])
    if trailer:
        _safe_tag_call(tag, "setTrailer", trailer)
    if status and media_type == "tvshow":
        _safe_tag_call(tag, "setTvShowStatus", status)
    if original_title:
        _safe_tag_call(tag, "setOriginalTitle", original_title)
    for source, data in source_ratings.items():
        _safe_tag_call(
            tag, "setRating", data["rating"], data["votes"], source,
            source == default_rating,
        )
        if source == "tmdb":
            _safe_tag_call(tag, "setRating", data["rating"], data["votes"], "themoviedb", False)

    unique_ids = {}
    for key in ("trakt", "tmdb", "imdb"):
        value = ids.get(key)
        if value not in (None, ""):
            unique_ids[key] = str(value)
    if unique_ids:
        default_id = "tmdb" if "tmdb" in unique_ids else ("imdb" if "imdb" in unique_ids else "trakt")
        _safe_tag_call(tag, "setUniqueIDs", unique_ids, default_id)
    _safe_tag_call(tag, "setMediaType", media_type)

def _library_items(media_type):
    """Load Kodi's library once per directory render and index it by stable IDs."""
    if media_type in _LIBRARY_CACHE:
        return _LIBRARY_CACHE[media_type]
    method = "VideoLibrary.GetTVShows" if media_type == "show" else "VideoLibrary.GetMovies"
    result_key = "tvshows" if media_type == "show" else "movies"
    request = {
        "jsonrpc": "2.0", "id": 1, "method": method,
        "params": {"properties": ["title", "year", "uniqueid"] + ([] if media_type == "show" else ["file"])},
    }
    rows = []
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        rows = response.get("result", {}).get(result_key, [])
        if not isinstance(rows, list):
            rows = []
    except (TypeError, ValueError, AttributeError):
        rows = []
    _LIBRARY_CACHE[media_type] = rows
    return rows


def _library_target(movie, media_type):
    ids = movie.get("ids") or {}
    wanted = {key: str(ids.get(key) or "").lower() for key in ("tmdb", "imdb")}
    title = str(movie.get("title") or "").strip().casefold()
    year = _safe_int(movie.get("year"), 0)
    for row in _library_items(media_type):
        unique = row.get("uniqueid") or {}
        id_match = any(wanted[key] and wanted[key] == str(unique.get(key) or "").lower() for key in wanted)
        title_match = title and title == str(row.get("title") or "").strip().casefold()
        year_match = not year or not _safe_int(row.get("year"), 0) or year == _safe_int(row.get("year"), 0)
        if not id_match and not (title_match and year_match):
            continue
        if media_type == "show":
            tvshow_id = _safe_int(row.get("tvshowid"), -1)
            if tvshow_id >= 0:
                return "videodb://tvshows/titles/%d/" % tvshow_id
        else:
            path = str(row.get("file") or "")
            if path:
                return path
    return ""


def _player_target(movie):
    media_type = "show" if str(movie.get("media_type") or "movie") == "show" else "movie"
    if PLAYERS.preference(media_type) == "information":
        return "", False, None
    library_url = _library_target(movie, media_type)
    if library_url:
        return library_url, media_type == "show", {"id": "kodi_library", "name": "Kodi Library"}
    url, player = PLAYERS.target(movie, media_type)
    if not player:
        return "", False, None
    return url, media_type == "show", player


def _play_using(params):
    media_type = "show" if params.get("media_type") == "show" else "movie"
    movie = {
        "title": params.get("title") or "",
        "year": _safe_int(params.get("year"), 0),
        "media_type": media_type,
        "overview": params.get("overview") or "",
        "ids": {
            "tmdb": params.get("tmdb_id") or "",
            "imdb": params.get("imdb_id") or "",
            "trakt": params.get("trakt_id") or "",
        },
    }
    choices = []
    library_url = _library_target(movie, media_type)
    if library_url:
        choices.append(("Kodi Library", library_url))
    for player in PLAYERS.available(media_type):
        url = PLAYERS.build_url(player, movie, media_type)
        if url:
            choices.append((player["name"], url))
    if not choices:
        xbmcgui.Dialog().ok(NAME, "No compatible installed player is available for this item.")
        return
    choice = xbmcgui.Dialog().select("Play using", [row[0] for row in choices])
    if choice < 0:
        return
    url = choices[choice][1]
    if media_type == "show":
        xbmc.executebuiltin("ActivateWindow(Videos,%s,return)" % url)
    else:
        xbmc.executebuiltin("PlayMedia(%s)" % url)


def _add_movie(movie, artwork, list_name="", list_id="", recommendation_actions=True):
    if not isinstance(movie, dict):
        return False
    media_type = str(movie.get("media_type") or "movie")
    title = str(movie.get("title") or ("Unknown show" if media_type == "show" else "Unknown movie"))
    year = _safe_int(movie.get("year"), 0)
    label = "%s (%d)" % (title, year) if year else title
    item = xbmcgui.ListItem(label=label, offscreen=True)
    _mark_curatr_item(item)
    _set_movie_info(item, movie)
    if artwork:
        try:
            item.setArt(artwork)
        except Exception as exc:
            xbmc.log("curatr artwork assignment skipped: %s" % exc, xbmc.LOGDEBUG)
    ids = movie.get("ids") or {}
    if not isinstance(ids, dict):
        ids = {}
    trakt_id = ids.get("trakt") or ""
    kodi_info_url = _url(action="kodi_info")
    why_url = _url(action="why", trakt_id=str(trakt_id), list_id=str(list_id), title=title, year=str(year or ""), media_type=media_type)
    hide_url = _url(action="hide", trakt_id=str(trakt_id), title=title, year=str(year or ""), media_type=media_type)
    if list_name:
        try:
            item.setProperty("CuratrList", list_name)
        except Exception:
            pass

    play_url, player_is_folder, _selected_player = _player_target(movie)
    try:
        context = []
        if PLAYERS.available(media_type):
            context.append(("Play Using…", "RunPlugin(%s)" % _url(
                action="play_using", media_type=media_type, title=title, year=str(year or ""),
                tmdb_id=str(ids.get("tmdb") or ""), imdb_id=str(ids.get("imdb") or ""),
                trakt_id=str(trakt_id), overview=str(movie.get("overview") or ""),
            )))
        if recommendation_actions:
            context.extend([
                ("Why this pick?", "RunPlugin(%s)" % why_url),
                ("Hide %s" % ("TV Show" if media_type == "show" else "Movie"), "RunPlugin(%s)" % hide_url),
            ])
        if _setting_enabled("context_menu_enabled"):
            media_params = {
                "media_type": media_type, "title": title, "year": str(year or ""),
                "tmdb_id": str(ids.get("tmdb") or ""), "imdb_id": str(ids.get("imdb") or ""),
                "tvdb_id": str(ids.get("tvdb") or ""), "trakt_id": str(trakt_id),
                "overview": str(movie.get("overview") or ""),
                "rating": str(movie.get("rating") or ""), "votes": str(movie.get("votes") or ""),
            }
            if _setting_enabled("context_add_to_list"):
                context.append((
                    _loc(32821, "Add to curatr list"),
                    _plugin_command("add_media_to_list", **media_params),
                ))
            if _setting_enabled("context_find_similar"):
                preview_url = _url(action="similar_preview", **media_params)
                context.append((
                    _loc(32823, "Find Similar"),
                    'ActivateWindow(Videos,"%s",return)' % preview_url.replace('"', "%22"),
                ))
        if list_id:
            refresh_url = _url(action="refresh_list", list_id=str(list_id))
            context.append(("Refresh this list", "RunPlugin(%s)" % refresh_url))
        item.addContextMenuItems(context)
    except Exception as exc:
        xbmc.log("curatr context menu skipped: %s" % exc, xbmc.LOGDEBUG)

    if play_url:
        try:
            item.setProperty("IsPlayable", "false" if player_is_folder else "true")
        except Exception:
            pass
        target_url = play_url
        is_folder = player_is_folder
    elif trakt_id or ids.get("tmdb") or title:
        try:
            item.setProperty("IsPlayable", "false")
        except Exception:
            pass
        target_url = kodi_info_url
        is_folder = False
    else:
        try:
            item.setProperty("IsPlayable", "false")
        except Exception:
            pass
        target_url = _url(action="linked_movie", title=title, year=str(year or ""))
        is_folder = True

    return bool(xbmcplugin.addDirectoryItem(HANDLE, target_url, item, isFolder=is_folder))


def _render_movies(curator, rows, category):
    xbmcplugin.setPluginCategory(HANDLE, category)
    rows = list(rows or [])
    enriched_rows = []
    for entry in rows:
        if len(entry) > 1 and isinstance(entry[1], dict):
            copied = list(entry)
            copied[1] = dict(entry[1])
            enriched_rows.append(tuple(copied))
        else:
            enriched_rows.append(entry)
    rows = enriched_rows
    try:
        METADATA.enrich(
            [entry[1] for entry in rows if len(entry) > 1 and isinstance(entry[1], dict)],
            curator.tmdb, curator.mdblist,
        )
    except Exception as exc:
        xbmc.log("curatr metadata enrichment skipped: %s" % exc, xbmc.LOGWARNING)
    media_types = {str(entry[1].get("media_type") or "movie") for entry in rows if len(entry) > 1 and isinstance(entry[1], dict)}
    xbmcplugin.setContent(HANDLE, "tvshows" if media_types == {"show"} else ("movies" if media_types <= {"movie"} else "videos"))
    art_cache = ArtworkCache(ADDON)

    # Artwork or one malformed movie must never make the entire skin widget fail.
    try:
        art_cache.prefetch_movies([entry[1] for entry in rows if len(entry) > 1 and isinstance(entry[1], dict)])
    except Exception as exc:
        xbmc.log("curatr artwork prefetch skipped: %s" % exc, xbmc.LOGWARNING)

    added = 0
    skipped = 0
    for entry in rows:
        try:
            if len(entry) < 2 or not isinstance(entry[1], dict):
                skipped += 1
                continue
            movie = entry[1]
            list_name = entry[2] if len(entry) > 2 else category
            list_id = entry[3] if len(entry) > 3 else ""
            recommendation_actions = bool(entry[4]) if len(entry) > 4 else True
            try:
                artwork = art_cache.art_for_movie(movie)
            except Exception as exc:
                artwork = {}
                xbmc.log("curatr artwork skipped for %s: %s" % (movie.get("title"), exc), xbmc.LOGDEBUG)
            if _add_movie(
                movie, artwork, list_name=list_name, list_id=list_id,
                recommendation_actions=recommendation_actions,
            ):
                added += 1
            else:
                skipped += 1
        except Exception as exc:
            skipped += 1
            xbmc.log("curatr movie row skipped: %s" % exc, xbmc.LOGWARNING)

    if not rows:
        _add_action("No items to show", "update", "Refresh your lists, then refresh this folder.")
    elif not added:
        _add_action("Items could not be displayed", "update", "The local list exists. Refresh it, or check Recent Activity for details.")

    # Sort constants vary slightly between Kodi builds/platforms.  In
    # particular, some Kodi 21 builds expose SORT_METHOD_VIDEO_YEAR but not
    # the older SORT_METHOD_YEAR alias.  Resolve each name defensively before
    # calling addSortMethod so a missing constant can never abort the listing.
    sort_names = (
        ("SORT_METHOD_UNSORTED",),
        ("SORT_METHOD_TITLE_IGNORE_THE", "SORT_METHOD_TITLE"),
        ("SORT_METHOD_VIDEO_YEAR", "SORT_METHOD_YEAR"),
        ("SORT_METHOD_VIDEO_RATING",),
    )
    seen_sorts = set()
    for names in sort_names:
        method = None
        for name in names:
            method = getattr(xbmcplugin, name, None)
            if method is not None:
                break
        if method is None or method in seen_sorts:
            continue
        seen_sorts.add(method)
        try:
            xbmcplugin.addSortMethod(HANDLE, method)
        except Exception as exc:
            xbmc.log("curatr sort method skipped: %s" % exc, xbmc.LOGDEBUG)
    if skipped:
        xbmc.log("curatr rendered %d movie(s), skipped %d" % (added, skipped), xbmc.LOGWARNING)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

def _single_list(curator, params):
    list_id = params.get("list_id") or params.get("trakt_id")
    if not list_id:
        raise RuntimeError("No curatr list ID was supplied.")
    if not curator._managed_record_by_id(list_id):
        xbmc.log("curatr widget requested a list that is no longer available", xbmc.LOGWARNING)
        xbmcplugin.setPluginCategory(HANDLE, "curatr List")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        return
    name = params.get("name") or "curatr Recommendations"
    rows = [(row, movie, name, list_id) for row, movie in _movie_rows_for_list(curator, list_id) if not curator.is_movie_hidden(movie)]
    _render_movies(curator, rows, name)


def _linked_list(curator, params):
    entry, movies = curator.linked_provider_list_movies(
        params.get("folder_id") or "", params.get("entry_id") or "",
        force=str(params.get("force") or "") == "1",
    )
    name = str(entry.get("name") or "Linked list")
    rows = [({}, movie, name, "", False) for movie in movies]
    _render_movies(curator, rows, name)


def _all(curator):
    _render_movies(curator, _movie_rows_all(curator), "All Picks")


def _fresh(curator):
    _render_movies(curator, _movie_rows_fresh(curator), "Latest Picks")


def _random_picks(curator, params):
    _render_movies(curator, _movie_rows_random(curator, params.get("limit") or 10), "Surprise Me")


def _similar_preview_file(token):
    safe = "".join(ch for ch in str(token or "") if ch.isalnum() or ch in ("-", "_"))[:64]
    if not safe:
        raise RuntimeError("That Find Similar preview is no longer available.")
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    return os.path.join(profile, "similar-preview-%s.json" % safe)


def _write_similar_preview(preview):
    token = "%d-%d" % (int(time.time()), random.randint(100000, 999999))
    path = _similar_preview_file(token)
    profile = os.path.dirname(path)
    try:
        _folders, files = xbmcvfs.listdir(profile)
        for filename in files:
            text = str(filename)
            if not text.startswith("similar-preview-") or not text.endswith(".json"):
                continue
            stamp = _safe_int(text[len("similar-preview-"):].split("-", 1)[0], 0)
            if not stamp or int(time.time()) - stamp > 6 * 3600:
                xbmcvfs.delete(os.path.join(profile, filename))
    except Exception:
        pass
    handle = xbmcvfs.File(path, "w")
    try:
        handle.write(json.dumps(preview, ensure_ascii=False, separators=(",", ":")))
    finally:
        handle.close()
    return token


def _read_similar_preview(token):
    path = _similar_preview_file(token)
    if not xbmcvfs.exists(path):
        raise RuntimeError("That Find Similar preview has expired. Run it again first.")
    handle = xbmcvfs.File(path)
    try:
        value = json.loads(handle.read() or "{}")
    finally:
        handle.close()
    if not isinstance(value, dict) or int(time.time()) - _safe_int(value.get("created_at"), 0) > 6 * 3600:
        try:
            xbmcvfs.delete(path)
        except Exception:
            pass
        raise RuntimeError("That Find Similar preview has expired. Run it again first.")
    return value


def _list_preview_file(token):
    safe = "".join(ch for ch in str(token or "") if ch.isalnum() or ch in ("-", "_"))[:64]
    if not safe:
        raise RuntimeError("That list preview is no longer available.")
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    return os.path.join(profile, "list-preview-%s.json" % safe)


def _write_list_preview(preview):
    token = "%d-%d" % (int(time.time()), random.randint(100000, 999999))
    handle = xbmcvfs.File(_list_preview_file(token), "w")
    try:
        handle.write(json.dumps(preview, ensure_ascii=False, separators=(",", ":")))
    finally:
        handle.close()
    return token


def _read_list_preview(token):
    path = _list_preview_file(token)
    if not xbmcvfs.exists(path):
        raise RuntimeError("That list preview has expired. Generate it again first.")
    handle = xbmcvfs.File(path)
    try:
        preview = json.loads(handle.read() or "{}")
    finally:
        handle.close()
    if not isinstance(preview, dict) or int(time.time()) - _safe_int(preview.get("created_at"), 0) > 6 * 3600:
        xbmcvfs.delete(path)
        raise RuntimeError("That list preview has expired. Generate it again first.")
    return preview


def _open_list_preview(preview):
    token = _write_list_preview(preview)
    xbmc.executebuiltin("ActivateWindow(Videos,%s,return)" % _url(action="list_preview", token=token))


def _list_preview(curator, params):
    token = params.get("token") or ""
    preview = _read_list_preview(token)
    record = dict(preview.get("record") or {})
    name = str(record.get("name") or "List Preview")
    xbmcplugin.setPluginCategory(HANDLE, "%s • Preview" % name)
    _add_route_action("Create list", "list_preview_save", "Save these exact previewed items to a new curatr list.", token=token, icon_name="menu_create_v2.png")
    _add_route_action("Edit list settings", "list_preview_edit", "Return to List Settings and change this list.", token=token, icon_name="menu_settings.png")
    _add_route_action("Close preview", "list_preview_close", "Discard this temporary preview.", token=token, icon_name="control_clear.png")
    rows = [({}, movie, name, "", False) for movie in record.get("movies", []) if isinstance(movie, dict)]
    _render_movies(curator, rows, "%s • Preview" % name)


def _similar_preview(curator, params):
    token = str(params.get("token") or "")
    previous = _read_similar_preview(token) if token else None
    reference = dict((previous or {}).get("reference") or {})
    if not reference:
        ids = {
            key: params.get(param) for key, param in (("tmdb", "tmdb_id"), ("imdb", "imdb_id"), ("tvdb", "tvdb_id"))
            if params.get(param)
        }
        reference = {
            "title": params.get("title") or "", "year": _safe_int(params.get("year"), 0),
            "media_type": "show" if params.get("media_type") == "show" else "movie", "ids": ids,
        }
    method = str(params.get("method") or "").lower()
    if method not in ("keyword", "ai"):
        method = str(ADDON.getSetting("context_similar_method") or "keyword").lower()
    count = max(5, min(50, _safe_int(ADDON.getSetting("context_similar_count"), 20)))
    preview = curator.build_similar_preview(reference, method=method, count=count)
    token = _write_similar_preview(preview)
    source = str(preview.get("title") or "Selected title")
    method_label = "AI" if method == "ai" else "Keyword Matching"
    xbmcplugin.setPluginCategory(HANDLE, "Similar to %s" % source)
    _add_route_action(
        "Add To New List", "similar_save",
        "Save these results to a new curatr list.", token=token,
        icon_name="menu_create_v2.png",
    )
    _add_folder(
        "Generate a new set of results", "similar_preview",
        "Generate another temporary preview using %s." % method_label,
        icon_name="menu_refresh.png", token=token, method=method,
    )
    other = "keyword" if method == "ai" else "ai"
    _add_folder(
        "Generate new results using %s" % ("keyword matching" if other == "keyword" else "AI"),
        "similar_preview", "Generate a new temporary preview using the other matching method.",
        icon_name="menu_branching_v2.png", token=token, method=other,
    )
    rows = [({}, movie, "Similar to %s" % source, "", False) for movie in preview.get("movies", [])]
    _render_movies(curator, rows, "Similar to %s • %s" % (source, method_label))


def _run_command(curator, command):
    actions = {
        "auth": curator.authenticate_trakt,
        "create": curator.create_list_interactive,
        "quick": curator.quick_pick_interactive,
        "templates": curator.prompt_templates_interactive,
        "hidden": curator.manage_hidden_interactive,
        "backup": curator.backup_menu_interactive,
        "update": curator.update_all,
        "manage": curator.manage_lists_interactive,
        "folders_manage": curator.manage_widget_folders_interactive,
        "folder_create": curator.create_widget_folder_interactive,
        "sync": curator.sync_profile,
        "taste": curator.view_taste_fingerprint,
        "usage": curator.show_ai_usage,
        "activity": curator.show_activity,
        "settings": lambda: (PLAYERS.update_status(), curator.open_settings())[-1],
        "status": lambda: curator.refresh_trakt_status(silent=False),
        "import_ai_key": lambda: curator.import_api_key_interactive("ai"),
        "import_tmdb_key": lambda: curator.import_api_key_interactive("tmdb"),
        "import_mdblist_key": lambda: curator.import_api_key_interactive("mdblist"),
        "test_tmdb": curator.test_tmdb_interactive,
        "test_mdblist": curator.test_mdblist_interactive,
        "choose_mdblist_lists": curator.choose_mdblist_lists_interactive,
        "privacy": curator.show_privacy_and_data,
        "choose_menu_background": curator.choose_menu_background_interactive,
        "choose_movie_player": lambda: PLAYERS.choose("movie"),
        "choose_show_player": lambda: PLAYERS.choose("show"),
        "install_community_players": PLAYERS.install_interactive,
    }
    function = actions.get(command)
    if not function:
        raise RuntimeError("Unknown addon action: %s" % command)
    before = list_signature(curator.state)
    result = function()
    if isinstance(result, dict) and result.get("kind") == "list_preview":
        _open_list_preview(result)
    refresh_if_changed(before, curator.state)


def _kodi_info():
    xbmc.executebuiltin("Action(Info)")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def main():
    global MENU_BACKGROUND_STYLE
    params = _params()
    action = params.get("action") or "root"
    curator = None
    try:
        curator = Curator(ADDON)
        MENU_BACKGROUND_STYLE = str(
            curator.state.get("menu_background_style")
            or ADDON.getSetting("menu_background_style")
            or "0"
        )
        before = list_signature(curator.state)
        if action == "root":
            curator.maybe_show_first_run()
            _root(curator)
        elif action == "my":
            _my(curator)
        elif action == "explore":
            _explore(curator)
        elif action == "taste_activity":
            _taste_activity(curator)
        elif action == "lists":
            _lists(curator)
        elif action == "folders":
            _folders(curator)
        elif action == "folder":
            _folder(curator, params)
        elif action == "folder_manage":
            curator.manage_widget_folder_interactive(params.get("folder_id") or "")
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "folder_artwork":
            curator.edit_widget_folder_artwork_interactive(params.get("folder_id") or "")
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "folder_delete":
            curator.delete_widget_folder_interactive(params.get("folder_id") or "")
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "folder_add_list":
            curator.add_list_to_widget_folder_interactive(list_id=params.get("list_id") or "")
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "folder_add_list_to":
            curator.add_list_to_widget_folder_interactive(folder_id=params.get("folder_id") or "")
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "folder_add_trakt":
            curator.add_provider_list_to_widget_folder_interactive(params.get("folder_id") or "", "trakt")
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "folder_add_mdblist":
            curator.add_provider_list_to_widget_folder_interactive(params.get("folder_id") or "", "mdblist")
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "folder_add_path":
            curator.add_external_path_interactive(params.get("folder_id") or "")
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "folder_import_favourite":
            curator.import_kodi_favourite_interactive(params.get("folder_id") or "")
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "folder_edit_entry":
            curator.edit_widget_folder_entry_interactive(
                params.get("folder_id") or "", params.get("entry_id") or ""
            )
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "folder_entry_artwork":
            curator.edit_widget_folder_entry_artwork_interactive(
                params.get("folder_id") or "", params.get("entry_id") or ""
            )
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "folder_remove_entry":
            curator.remove_widget_folder_entry_interactive(
                params.get("folder_id") or "", params.get("entry_id") or ""
            )
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "create_related_local":
            curator.create_related_list_interactive(list_id=params.get("list_id") or "")
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "create_related_provider":
            curator.create_related_list_interactive(
                folder_id=params.get("folder_id") or "", entry_id=params.get("entry_id") or ""
            )
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "linked_list":
            _linked_list(curator, params)
            refresh_if_changed(before, curator.state)
        elif action == "linked_movie":
            title = params.get("title") or "This movie"
            xbmcgui.Dialog().ok(NAME, "%s is listed here without a playable TMDB or Trakt ID. Open it through your preferred video add-on." % title)
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        elif action == "external_missing":
            xbmcgui.Dialog().ok(NAME, "The add-on used by '%s' is not currently installed or enabled.\n\n%s" % (
                params.get("name") or "this shortcut", params.get("addon_id") or "Unknown add-on",
            ))
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        elif action == "list":
            _single_list(curator, params)
        elif action == "all":
            _all(curator)
        elif action == "fresh":
            _fresh(curator)
        elif action == "random":
            _random_picks(curator, params)
        elif action == "similar_preview":
            _similar_preview(curator, params)
        elif action == "add_media_to_list":
            curator.add_media_to_list_interactive({
                "title": params.get("title") or "",
                "year": _safe_int(params.get("year"), 0),
                "media_type": "show" if params.get("media_type") == "show" else "movie",
                "overview": params.get("overview") or "",
                "rating": params.get("rating") or None,
                "votes": _safe_int(params.get("votes"), 0),
                "ids": {
                    key: params.get(param) for key, param in (
                        ("tmdb", "tmdb_id"), ("imdb", "imdb_id"),
                        ("tvdb", "tvdb_id"), ("trakt", "trakt_id"),
                    ) if params.get(param)
                },
            })
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "similar_save":
            curator.save_similar_preview_interactive(_read_similar_preview(params.get("token") or ""))
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "list_preview":
            _list_preview(curator, params)
        elif action == "list_preview_save":
            token = params.get("token") or ""
            saved = curator.save_list_preview(_read_list_preview(token))
            if saved:
                xbmcvfs.delete(_list_preview_file(token))
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "list_preview_edit":
            token = params.get("token") or ""
            preview = _read_list_preview(token)
            result = curator.create_list_interactive(initial=preview.get("draft") or {})
            if isinstance(result, dict) and result.get("kind") == "list_preview":
                xbmcvfs.delete(_list_preview_file(token))
                _open_list_preview(result)
            elif result:
                xbmcvfs.delete(_list_preview_file(token))
                xbmc.executebuiltin("Action(Back)")
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "list_preview_close":
            xbmcvfs.delete(_list_preview_file(params.get("token") or ""))
            xbmc.executebuiltin("Action(Back)")
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        elif action == "run":
            _run_command(curator, params.get("command") or "")
        elif action == "play_using":
            _play_using(params)
        elif action == "refresh_list":
            list_id = params.get("list_id") or params.get("trakt_id") or ""
            curator.refresh_list(list_id, silent=False)
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "edit_list":
            list_id = params.get("list_id") or params.get("trakt_id") or ""
            curator.edit_list_interactive(list_id)
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "artwork_list":
            list_id = params.get("list_id") or params.get("trakt_id") or ""
            curator.list_artwork_interactive(list_id)
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "sync_list":
            list_id = params.get("list_id") or params.get("trakt_id") or ""
            curator.sync_list_to_trakt_interactive(list_id)
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "delete_list":
            list_id = params.get("list_id") or params.get("trakt_id") or ""
            curator.delete_list_interactive(list_id)
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "why":
            curator.why_recommended(
                params.get("list_id") or "", params.get("trakt_id") or "",
                params.get("title") or "", _safe_int(params.get("year"), 0),
                media_type="show" if params.get("media_type") == "show" else "movie",
            )
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
        elif action == "hide":
            curator.hide_movie(
                params.get("trakt_id") or "", params.get("title") or "",
                _safe_int(params.get("year"), 0), confirm=True,
                media_type="show" if params.get("media_type") == "show" else "movie",
            )
            xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
            refresh_if_changed(before, curator.state)
        elif action == "kodi_info":
            _kodi_info()
        else:
            raise RuntimeError("Unknown plugin route: %s" % action)
    except (CatalogueError, TraktError, RuntimeError) as exc:
        xbmc.log("curatr plugin error: %s" % exc, xbmc.LOGERROR)
        if curator is not None:
            try:
                curator.report_error("Plugin request failed", detail=str(exc))
            except Exception:
                pass
        xbmcgui.Dialog().ok(NAME, str(exc))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
    except Exception as exc:
        xbmc.log("curatr plugin unexpected error: %s" % exc, xbmc.LOGERROR)
        if curator is not None:
            try:
                curator.report_error("Recommendations view hit an unexpected error", detail=str(exc))
            except Exception:
                pass
        xbmcgui.Dialog().ok(NAME, "%s: %s" % (_loc(32490, "Error"), exc))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)


if __name__ == "__main__":
    main()
