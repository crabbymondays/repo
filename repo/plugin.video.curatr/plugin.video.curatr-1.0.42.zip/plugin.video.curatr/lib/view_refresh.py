"""Keep Kodi directory views and skin widgets in step with local list changes."""

import hashlib
import json

import xbmc
import xbmcgui


def in_video_navigation():
    try:
        return xbmcgui.getCurrentWindowId() == 10025 or bool(xbmc.getCondVisibility("Window.IsActive(videos)"))
    except Exception:
        return False


def directory_command(url, replace=False):
    """Keep directory history in Videos and the originating window elsewhere."""
    target = str(url).replace('"', '%22')
    if in_video_navigation():
        return 'Container.Update("%s"%s)' % (target, ",replace" if replace else "")
    return 'ActivateWindow(Videos,"%s",return)' % target


def open_directory(url, replace=False):
    xbmc.executebuiltin(directory_command(url, replace=replace))


def list_signature(state):
    linked_cache = state.get("linked_list_cache", {}) if isinstance(state, dict) else {}
    linked_summary = {
        str(key): {
            "cached_at": (value or {}).get("cached_at", 0),
            "count": len((value or {}).get("movies", [])) if isinstance((value or {}).get("movies"), list) else 0,
        }
        for key, value in linked_cache.items()
        if isinstance(value, dict)
    } if isinstance(linked_cache, dict) else {}
    records = {
        "ai_lists": state.get("ai_lists", []),
        "dynamic_lists": state.get("dynamic_lists", []),
        "hidden_movies": state.get("hidden_movies", []),
        "widget_folders": state.get("widget_folders", []),
        "linked_list_cache": linked_summary,
        "menu_background_style": state.get("menu_background_style"),
        "menu_background_source": state.get("menu_background_source"),
    } if isinstance(state, dict) else {}
    try:
        payload = json.dumps(records, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    except (TypeError, ValueError):
        payload = repr(records)
    return hashlib.sha256(payload.encode("utf-8", "replace")).hexdigest()


def refresh_if_changed(before, state, appearance_changed=False):
    """Refresh an open curatr view without moving users away from their screen."""
    if not appearance_changed and before == list_signature(state):
        return False
    in_curatr = False
    try:
        plugin_name = str(xbmc.getInfoLabel("Container.PluginName") or "").strip()
        folder_path = str(xbmc.getInfoLabel("Container.FolderPath") or "").strip()
        in_curatr = plugin_name == "plugin.video.curatr" or folder_path.startswith("plugin://plugin.video.curatr")
    except Exception:
        pass
    if in_curatr and in_video_navigation():
        try:
            xbmc.executebuiltin("Container.Refresh")
        except Exception:
            pass
        return True
    return True
